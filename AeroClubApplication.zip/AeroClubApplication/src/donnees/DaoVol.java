package donnees;

import domaine.Vol;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import java.security.GeneralSecurityException;
import org.postgresql.Driver;

	public class DaoVol{
		PreparedStatement prep;
		Statement stat;
		Connection connection;
		String chemin;//("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
                String user;
                String pass;
                Vol vol;
                ArrayList<Vol> list;
                 DaoMembre daoM = new DaoMembre("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                 DaoAvion daoA = new DaoAvion("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                 DaoInstructeur daoI = new DaoInstructeur("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                
		public DaoVol(String pChemin, String puser, String ppass){
                    try{
                        this.chemin = pChemin;
                        this.user=puser;
                        this.pass = ppass;
                        Class.forName("org.postgresql.Driver");
                        this.connection = DriverManager.getConnection(pChemin, puser, ppass);
                    }
                    catch(ClassNotFoundException eX){
                        System.out.println("Class non trouvée");
                        eX.printStackTrace();
                    }
                    catch(SQLException sX){
                        System.out.println("SQL error création objet");
                        sX.printStackTrace();
                    }
                    if (this.connection!=null){
                        System.out.println("Connexion réussie");
                     }
                    else{
                         System.out.println("Connexion échouée");  
                    }
		}
		
		public Vol litVol(int numero) throws GeneralSecurityException, IOException{
			try{
                            this.prep = this.connection.prepareStatement("Select * FROM vol WHERE numero =?");
                            this.prep.setInt(1,numero);
                            ResultSet res = this.prep.executeQuery();
                            
                            while(res.next()){
                                     vol = new Vol(res.getInt("numero"), daoM.litMembre(res.getInt("numeromembre")), daoI.litInstructeur(res.getInt("numeroinstructeur")), daoA.litAvionNumero(res.getInt("numeroAvion")), res.getString("date"), res.getInt("duree"));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire vol");
                            eX.printStackTrace();
			}
			return vol;
		}
                
                public void ajouterVol(Vol vol){
			try{
                            this.prep = this.connection.prepareStatement("INSERT INTO vol (numeromembre, numeroinstructeur, numeroavion, date, duree) VALUES(?,?,?,?,?) ");
                            this.prep.setInt(1,vol.getParticipant().getNumero());
                            this.prep.setInt(2,vol.getInstructeur().getNumero());
                            this.prep.setInt(3, vol.getAvion().getNumero());
                            this.prep.setString(4, vol.getDateVol());
                            this.prep.setInt(5, vol.getDuree());
                            this.prep.execute();
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire vol");
                            eX.printStackTrace();
			}
		}
                
                public void supprimerVol(int numero){
			try{
                            this.prep = this.connection.prepareStatement("DELETE FROM vol where numero = ? ");
                            this.prep.setInt(1, numero);
                            ResultSet res = this.prep.executeQuery();
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error supprimer vol");
                            eX.printStackTrace();
			}
		}
                
                
                public ArrayList<Vol> litVolsDunMembre(int numeromembre) throws IOException, GeneralSecurityException{
			try{
                            list = new ArrayList<>();
                            this.prep = this.connection.prepareStatement("Select * FROM vol WHERE numeromembre =?");
                            this.prep.setInt(1,numeromembre);
                            ResultSet res = this.prep.executeQuery();
                            
                            while(res.next()){
                                     list.add(new Vol(res.getInt("numero"), daoM.litMembre(res.getInt("numeromembre")), daoI.litInstructeur(res.getInt("numeroinstructeur")), daoA.litAvionNumero(res.getInt("numeroAvion")), res.getString("date"), res.getInt("duree")));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire vols d'un membre");
                            eX.printStackTrace();
			}
			return list;
		}
                
		public ArrayList<Vol> tousLesVols() throws GeneralSecurityException, IOException{
			try{
                            list= new ArrayList<>();
                            this.prep = this.connection.prepareStatement("SELECT * FROM vol ORDER BY numero");
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                list.add(new Vol(res.getInt("numero"), daoM.litMembre(res.getInt("numeromembre")), daoI.litInstructeur(res.getInt("numeroinstructeur")), daoA.litAvionNumero(res.getInt("numeroAvion")), res.getString("date"), res.getInt("duree")));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lister tous les avions");
                            eX.printStackTrace();
			}
			return list;
		}

}
package donnees;

import domaine.Vol;
import domaine.VolForfait;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import java.security.GeneralSecurityException;
import org.postgresql.Driver;

	public class DaoVolForfait{
		PreparedStatement prep;
		Statement stat;
		Connection connection;
		String chemin;//("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
                String user;
                String pass;
                VolForfait vol;
                ArrayList<VolForfait> list;
                 DaoMembre daoM = new DaoMembre("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                 DaoAvion daoA = new DaoAvion("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                 DaoForfait daoF = new DaoForfait("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                
		public DaoVolForfait(String pChemin, String puser, String ppass){
                    try{
                        this.chemin = pChemin;
                        this.user=puser;
                        this.pass = ppass;
                        Class.forName("org.postgresql.Driver");
                        this.connection = DriverManager.getConnection(pChemin, puser, ppass);
                    }
                    catch(ClassNotFoundException eX){
                        System.out.println("Class non trouvée");
                        eX.printStackTrace();
                    }
                    catch(SQLException sX){
                        System.out.println("SQL error création objet");
                        sX.printStackTrace();
                    }
                    if (this.connection!=null){
                        System.out.println("Connexion réussie");
                     }
                    else{
                         System.out.println("Connexion échouée");  
                    }
		}
		
		public VolForfait litVol(int numero) throws GeneralSecurityException, IOException{
			try{
                            this.prep = this.connection.prepareStatement("Select * FROM volforfait WHERE numero =?");
                            this.prep.setInt(1,numero);
                            ResultSet res = this.prep.executeQuery();
                            
                            while(res.next()){
                                     vol = new VolForfait(res.getInt("numero"), daoF.litforfait(res.getInt("numeroforfait")).getTitulaire(), null, daoF.litforfait(res.getInt("numeroforfait")).getAvion(), res.getString("date"), res.getInt("duree"), daoF.litforfait(res.getInt("numeroforfait")));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire vol");
                            eX.printStackTrace();
			}
			return vol;
		}
                
                public void ajouterVol(VolForfait vol){
			try{
                            this.prep = this.connection.prepareStatement("INSERT INTO volforfait (date, duree, numeroforfait) VALUES(?,?,?) ");
                            this.prep.setString(1,vol.getDateVol());
                            this.prep.setInt(2,vol.getDuree());
                            this.prep.setInt(3, vol.getLeForfait().getNumero());
                            this.prep.execute();
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error ajouter vol forfait");
                            eX.printStackTrace();
			}
		}
                
                public void supprimerVol(int numero){
			try{
                            this.prep = this.connection.prepareStatement("DELETE FROM volforfait where numero = ? ");
                            this.prep.setInt(1, numero);
                            ResultSet res = this.prep.executeQuery();
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error supprimer vol");
                            eX.printStackTrace();
			}
		}
                
                
                public ArrayList<VolForfait> litVolsDunMembre(int numeromembre) throws IOException, GeneralSecurityException{
			try{
                            list = new ArrayList<>();
                            this.prep = this.connection.prepareStatement("Select * FROM volforfait WHERE numeroforfait = (SELECT numero from forfait where numeromembre = ?)");
                            this.prep.setInt(1,numeromembre);
                            ResultSet res = this.prep.executeQuery();
                            
                            while(res.next()){
                                     list.add(vol = new VolForfait(res.getInt("numero"), daoF.litforfait(res.getInt("numeroforfait")).getTitulaire(), null, daoF.litforfait(res.getInt("numeroforfait")).getAvion(), res.getString("date"), res.getInt("duree"), daoF.litforfait(res.getInt("numeroforfait"))));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire vols d'un membre");
                            eX.printStackTrace();
			}
			return list;
		}
                
		public ArrayList<VolForfait> tousLesVols() throws GeneralSecurityException, IOException{
			try{
                            list= new ArrayList<>();
                            this.prep = this.connection.prepareStatement("SELECT * FROM volforfait ORDER BY numero");
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                list.add(vol = new VolForfait(res.getInt("numero"), daoF.litforfait(res.getInt("numeroforfait")).getTitulaire(), null, daoF.litforfait(res.getInt("numeroforfait")).getAvion(), res.getString("date"), res.getInt("duree"), daoF.litforfait(res.getInt("numeroforfait"))));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lister tous les avions");
                            eX.printStackTrace();
			}
			return list;
		}

}
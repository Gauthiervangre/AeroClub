package donnees;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import java.util.logging.Level;
import java.util.logging.Logger;
import domaine.Compte;
import org.postgresql.Driver;
import domaine.Instructeur;

public class DaoCompte{
	PreparedStatement prep;
	Statement stat;
	Connection connection;
	String chemin; //("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
    String user;
    String pass;
    Compte compte;

	public DaoCompte(String pChemin, String puser, String ppass){
            try{
                this.chemin = pChemin;
                this.user = puser;
                this.pass = ppass;
                Class.forName("org.postgresql.Driver");
                this.connection = DriverManager.getConnection(pChemin, puser, ppass);
            }
            catch(ClassNotFoundException eX){
                System.out.println("Class non trouvée");
                eX.printStackTrace();
            }
            catch(SQLException sX){
                System.out.println("SQL error création objet");
                sX.printStackTrace();
            }
            if (this.connection!=null){
                System.out.println("Connexion réussie");
            }
            else{
                System.out.println("Connexion échouée");  
            }
        }

	public Compte litCompte(int numero){
            try{
                this.prep = this.connection.prepareStatement("SELECT * FROM compte WHERE numero= ?");
                this.prep.setLong(1, numero);
                ResultSet res = this.prep.executeQuery();
                DaoMembre dao = new DaoMembre("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                while(res.next()){
                        compte= new Compte(numero, dao.litMembre(res.getInt("numeromembre")), res.getDouble("solde"));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error lire instructeur");
                eX.printStackTrace();
            }
            return compte;
            }
        
        public Compte litCompteDunMembre(int numeromembre){
            try{
                this.prep = this.connection.prepareStatement("SELECT * FROM compte WHERE numeromembre= ?");
                this.prep.setLong(1, numeromembre);
                ResultSet res = this.prep.executeQuery();
                DaoMembre dao = new DaoMembre("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
                while(res.next()){
                        compte= new Compte(res.getInt("numero"), dao.litMembre(res.getInt("numeromembre")), res.getDouble("solde"));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error lire instructeur");
                eX.printStackTrace();
            }
            return compte;
            }
        
		
        public void crediter(int numero, double solde){
            if (solde > 0){
                try {
                    this.prep = this.connection.prepareStatement("UPDATE compte SET solde = solde + ? WHERE numero = ?");
                    this.prep.setDouble(1, solde);
                    this.prep.setInt(2, numero);
                    this.prep.execute();
                } catch (SQLException ex) {
                    Logger.getLogger(DaoCompte.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        public void CreerCompte(int numeromembre){
             try {
                    this.prep = this.connection.prepareStatement("INSERT INTO compte (solde, numeromembre) VALUES (?,?)");
                    this.prep.setDouble(1, 0);
                    this.prep.setInt(2, numeromembre);
                    this.prep.execute();
                } catch (SQLException ex) {
                    System.out.println("SQL error créer compte");
                    ex.printStackTrace();
                }
        }
        
        public void debiter(int numero, double solde){
            if (solde > 0){
                try {
                    this.prep = this.connection.prepareStatement("UPDATE compte SET solde = solde - ? WHERE numero = ?");
                    this.prep.setDouble(1, solde);
                    this.prep.setInt(2, numero);
                    this.prep.execute();
                } catch (SQLException ex) {
                    Logger.getLogger(DaoCompte.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
           
        }

        public void supprimerCompte(int numero){
		try{
                    this.prep = this.connection.prepareStatement("DELETE FROM compte WHERE numero = ?");
                    this.prep.setLong(1, numero);
                    this.prep.execute();
                }
                catch (SQLException eX)
                {
                    System.out.println("SQL error supprimer compte");
                    eX.printStackTrace();
                }
	}
		
        
}

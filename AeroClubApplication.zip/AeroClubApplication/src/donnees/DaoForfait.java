package donnees;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import java.security.GeneralSecurityException;
import org.postgresql.Driver;
import domaine.*;


public class DaoForfait{
	PreparedStatement prep;
	Statement stat;
	Connection connection;
	String chemin; //("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
        String user;
        String pass;
        ArrayList<ForfaitHeure> listforfait;
        ArrayList<ForfaitHeure> mesForfaits;
        ForfaitHeure forfait;
        DaoMembre daoM = new DaoMembre("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
        DaoAvion daoA = new DaoAvion("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");

	public DaoForfait(String pChemin, String puser, String ppass){
            try{
                this.chemin = pChemin;
                this.user = puser;
                this.pass = ppass;
                Class.forName("org.postgresql.Driver");
                this.connection = DriverManager.getConnection(pChemin, puser, ppass);
            }
            catch(ClassNotFoundException eX){
                System.out.println("Class non trouvée");
                eX.printStackTrace();
            }
            catch(SQLException sX){
                System.out.println("SQL error création objet");
                sX.printStackTrace();
            }
            if (this.connection!=null){
                System.out.println("Connexion réussie");
            }
            else{
                System.out.println("Connexion échouée");  
            }
        }

	public ForfaitHeure litforfait(int numero) throws GeneralSecurityException, IOException{
            try{
                this.prep = this.connection.prepareStatement("SELECT * FROM forfait WHERE numero= ?");
                this.prep.setLong(1, numero);
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                       forfait = new ForfaitHeure(res.getInt("numero"),daoM.litMembre(res.getInt("numeromembre")), daoA.litAvionNumero(res.getInt("numeroavion")), res.getInt("nbheure"), res.getInt("nbheurerestante"), res.getInt("nbheurefaite"), res.getDouble("montant"));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error lire forfait");
                eX.printStackTrace();
            }
            return forfait;
        }
        
        public ArrayList<ForfaitHeure> litforfaitsDunMembre(int numeromembre) throws GeneralSecurityException, IOException{
            try{
                mesForfaits = new ArrayList<>();
                this.prep = this.connection.prepareStatement("SELECT * FROM forfait WHERE numeromembre= ?");
                this.prep.setLong(1, numeromembre);
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                       mesForfaits.add(new ForfaitHeure(res.getInt("numero"),daoM.litMembre(numeromembre), daoA.litAvionNumero(res.getInt("numeroavion")), res.getInt("nbheure"), res.getInt("nbheurerestante"), res.getInt("nbheurefaite"), res.getDouble("montant")));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error lire forfait membre");
                eX.printStackTrace();
            }
            return mesForfaits;
        }
		
	public void ajouterforfait(ForfaitHeure forfait){
            try{
			
                this.prep = this.connection.prepareStatement("INSERT INTO forfait (nbheure, nbheurerestante, nbheurefaite, montant, numeromembre, numeroavion) VALUES(?,?,?,?,?,?)");
                this.prep.setInt(1, forfait.getNbheure());
                this.prep.setInt(2, forfait.getNbHeuresRestante());
                this.prep.setInt(3, forfait.getNbHeuresFaites());
                this.prep.setDouble(4, forfait.getMontant());
                this.prep.setInt(5, forfait.getTitulaire().getNumero());
                this.prep.setInt(6, forfait.getAvion().getNumero());
              
                this.prep.execute();
            }
            catch (SQLException eX)
            {
              System.out.println("SQL error ajouter forfait");
              eX.printStackTrace();
            }
        }
		

        public void supprimerforfait(int numero){
		try{
                    this.prep = this.connection.prepareStatement("DELETE FROM forfait WHERE numero = ?");
                    this.prep.setLong(1, numero);
                    this.prep.execute();
                }
                catch (SQLException eX)
                {
                    System.out.println("SQL error supprimer forfait");
                    eX.printStackTrace();
                }
	}
        
        public void updateForfait(int numeroForfait, int nbHeureFaitesUpdated, int nbheureRestanteUpdated){ //Update nb heures faites du forfait
                 try{
                    this.prep = this.connection.prepareStatement("UPDATE forfait set nbheurefaite = nbheurefaite +?, nbheurerestante = ? where numero = ?");
                    this.prep.setInt(1, nbHeureFaitesUpdated);
                    this.prep.setInt(2, nbheureRestanteUpdated);
                    this.prep.setInt(3, numeroForfait);
                    this.prep.execute();
                }
                catch (SQLException eX)
                {
                    System.out.println("SQL error supprimer forfait");
                    eX.printStackTrace();
                }
        }
		
        public ArrayList<ForfaitHeure> tousLesforfaits() throws GeneralSecurityException, IOException{
            listforfait = new ArrayList();
            try{
                this.prep=this.connection.prepareStatement("SELECT * FROM forfait");
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                    listforfait.add(new ForfaitHeure(res.getInt("numero"),daoM.litMembre(res.getInt("numeromembre")), daoA.litAvionNumero(res.getInt("numeroavion")), res.getInt("nbheure"), res.getInt("nbheurerestante"), res.getInt("nbheurefaite"), res.getDouble("montant")));
                }
                
            }
            catch (SQLException eX)
            {
              System.out.println("SQL error lister tous les forfaits");
              eX.printStackTrace();
            }
            return listforfait;
        }
}

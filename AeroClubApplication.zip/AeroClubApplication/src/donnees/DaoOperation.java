package donnees;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import java.sql.Date;
import org.postgresql.Driver;
import domaine.Membre;
import domaine.OperationSurCompte;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;

public class DaoOperation{
    PreparedStatement prep;
    Statement stat;
    Connection connection;
    String chemin;//("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
    String user;
    String pass;
    ArrayList<OperationSurCompte> list;
    OperationSurCompte operation;
    DaoMembre dao = new DaoMembre("jdbc:postgresql://192.168.190.21/AeroClub", "aeroclub", "root");
	
	public DaoOperation(String pChemin,String puser, String ppass){
            try{
                this.chemin = pChemin;
                this.user=puser;
                this.pass = ppass;
                Class.forName("org.postgresql.Driver");
                this.connection = DriverManager.getConnection(pChemin, puser, ppass);
            }
            catch(ClassNotFoundException eX){
                System.out.println("Class non trouvée");
                eX.printStackTrace();
            }
            catch(SQLException sX){
                System.out.println("SQL error création objet");
                sX.printStackTrace();
            }
            if (this.connection!=null){
                System.out.println("Connexion réussie");
            }
            else{
              System.out.println("Connexion échouée");  
            }
        }
        
        public String litTypeOperation(int numerotype){
                    String libelle = null;
            try{
                    this.prep = this.connection.prepareStatement("SELECT libelle from typeoperation WHERE numero = ?");
                    this.prep.setLong(1, numerotype);
                    ResultSet res = this.prep.executeQuery();
                    while(res.next()){
                        libelle = res.getString("libelle");
                    }
		}
		catch (SQLException eX)
		{
                    System.out.println("SQL error lire operation");
                    eX.printStackTrace();
		}
		return libelle; 
        }
        
        public int litNumeroOperation(String libelle){
                    int numero = 0;
            try{
                    this.prep = this.connection.prepareStatement("SELECT numero from typeoperation WHERE libelle = ?");
                    this.prep.setString(1, libelle);
                    ResultSet res = this.prep.executeQuery();
                    while(res.next()){
                        numero = res.getInt("numero");
                    }
		}
		catch (SQLException eX)
		{
                    System.out.println("SQL error lire operation");
                    eX.printStackTrace();
		}
		return numero; 
        }

	public OperationSurCompte litOperation(int numero) throws GeneralSecurityException, IOException{
		try{
                    this.prep = this.connection.prepareStatement("SELECT * FROM operations WHERE numero = ?");
                    this.prep.setLong(1, numero);
                    ResultSet res = this.prep.executeQuery();
                    while(res.next()){
                        operation = new OperationSurCompte(numero, litTypeOperation(res.getInt("numerotype")), res.getDouble("montant"), res.getDate("date"), dao.litMembre(res.getInt("numeromembre")), res.getString("detail"), res.getTime("temps"));
                    }
		}
		catch (SQLException eX)
		{
                    System.out.println("SQL error lire operation");
                    eX.printStackTrace();
		}
		return operation;
	}
	
	public void ajouterOperation(OperationSurCompte operation){
		try{
                    this.prep = this.connection.prepareStatement("INSERT INTO operations (montant, date, numerotype, numeromembre, detail, temps) VALUES(?,?,?,?,?,?)");
                    this.prep.setDouble(1,operation.getMontant());
                    this.prep.setDate(2, java.sql.Date.valueOf(new SimpleDateFormat("yyyy-MM-dd").format(operation.getDate())));
                    this.prep.setInt(3, operation.getNumeroType());
                    this.prep.setInt(4, operation.getMembre().getNumero());
                    this.prep.setString(5, operation.getDetail());
                    this.prep.setTime(6, operation.getTemps());
                    this.prep.execute();
		}
		catch (SQLException eX)
		{
		  System.out.println("SQL error ajouter operation");
                  eX.printStackTrace();
		}
	}
        
	public void supprimerOperation(int numero){
		try{
		
			this.prep = this.connection.prepareStatement("DELETE FROM operations WHERE numero= ?");
			this.prep.setLong(1, numero);
			this.prep.execute();
		}
		catch (SQLException eX)
		{
		  System.out.println("SQL error supprimer operation");
                  eX.printStackTrace();
		}
	}
	
	public ArrayList<OperationSurCompte> toutesLesOperationsDunMembre(int numeromembre) throws GeneralSecurityException, IOException{
            list = new ArrayList<>();
            try{
                this.prep=this.connection.prepareStatement("SELECT * FROM operations where numeromembre = ?");
                this.prep.setInt(1, numeromembre);
                ResultSet res = this.prep.executeQuery();
                while (res.next()){
                    list.add(new OperationSurCompte(res.getInt("numero"), litTypeOperation(res.getInt("numerotype")), res.getDouble("montant"), res.getDate("date"), dao.litMembre(res.getInt("numeromembre")), res.getString("detail"), res.getTime("temps")));
                }
            }
            catch (SQLException eX){
		     System.out.println("SQL error lister operation d'un membre");
                  eX.printStackTrace();
            }
            return list;
	}

}

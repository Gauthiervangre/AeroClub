package test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import tools.Cryption;
import donnees.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import tools.*;

public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ParseException {
       /*String mdp = "test";
       Cryption cryption = new Cryption();
       String mdp_crypte = cryption.encrypt(mdp);
       System.out.println("Mot de passe crypté : " + mdp_crypte);
       String mdp_decrypt = cryption.decrypt(mdp_crypte);
       System.out.println("Mot de passe décrypté : " + mdp_decrypt);
       System.out.println("Mot de passe original : " + mdp); 
       
       if (mdp.equals(mdp_decrypt)){
           System.out.println("Le cryptage s'est bien déroulé !");
        
       }
        
       
       */
        
       DaoMembre dao = new DaoMembre("jdbc:postgresql://192.168.190.21/AeroClub", "aeroclub", "root");
       
        System.out.println(dao.tousLesMembres().size());
       
                
        
        
    }
    
}

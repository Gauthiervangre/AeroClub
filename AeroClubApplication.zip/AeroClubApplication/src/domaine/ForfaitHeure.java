/*
-----------------------------------------------------------TABLE FORFAIT A FAIRE------------------------------------------------------------
 */
package domaine;


import donnees.DaoForfait;
import java.util.Objects;

/**
 *
 * @author vangr
 */
public class ForfaitHeure {
    private Membre titulaire;
    private int nbHeure;
    private int nbHeuresRestantes;
    private Avion avion;
    private int nbHeuresFaites;
    private double montant;
    private int numero;
    DaoForfait dao = new DaoForfait("jdbc:postgresql://192.168.190.21/AeroClub", "aeroclub", "root");
    
    
    public ForfaitHeure(int numero, Membre titulaire,  Avion avion,  int nbHeure, int nbHeureRestante, int nbHeureFaites, double montant){
        this.numero = numero;
        this.titulaire = Objects.requireNonNull(titulaire, "membre null");
        this.avion = avion;
        this.nbHeure = nbHeure;
        this.nbHeuresRestantes = nbHeureRestante;
        this.nbHeuresFaites = nbHeureFaites;
        this.montant = montant;
    //this.montant =  avion.getTauxHoraire() * (double)nbHeure;  
        //titulaire.getCompte().debiterCompte(montant);
    }
    
    public ForfaitHeure(Membre titulaire, Avion avion, int nbHeure, int nbHeureRestante, int nbHeureFaites, double montant){
         this.titulaire = Objects.requireNonNull(titulaire, "membre null");
        this.avion = Objects.requireNonNull(avion, "avion null");
        this.nbHeure = nbHeure;
        this.nbHeuresRestantes = nbHeureRestante;
        this.nbHeuresFaites = nbHeureFaites;
        this.montant = montant;
    }
    
    public Membre getTitulaire(){
        return titulaire;
    }
    
    public int getNumero(){
        return numero;
    }
    
    public Avion getAvion(){
        return avion;
    }
    
    public int getNbheure(){
        return nbHeure;
    }
    
    public double getMontant(){
        return montant;
    }
    
    public int getNbHeuresRestante(){
        return nbHeuresRestantes;      
    }
    
    public int getNbHeuresFaites(){
        return nbHeuresFaites;
    }
    
    public void setNbHeuresFaites(int nbHeureFaite, int nbHeureRestante){ // Mettre à jour les heures restantes du forfait
            dao.updateForfait(this.numero, nbHeureFaite, nbHeureRestante);
    }
    
    public void AjouterNbHeuresFaites(int nbHeureF){ // Incrémente le nombre d'heures faites
        this.nbHeuresFaites += nbHeureF;
    }
}

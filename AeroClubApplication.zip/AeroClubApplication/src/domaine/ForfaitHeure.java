/*
-----------------------------------------------------------TABLE FORFAIT A FAIRE------------------------------------------------------------
 */
package domaine;


import java.util.Objects;

/**
 *
 * @author vangr
 */
public class ForfaitHeure {
    private Membre titulaire;
    private int nbHeure;
    private int nbHeuresRestantes;
    private Avion avion;
    private int nbHeuresFaites;
    private double montant;
    private int numero;
    
    
    public ForfaitHeure(int numero, Membre titulaire,  Avion avion,  int nbHeure, int nbHeureRestante, int nbHeureFaites, double montant){
        this.numero = numero;
        this.titulaire = Objects.requireNonNull(titulaire, "membre null");
        this.avion = avion;
        this.nbHeure = nbHeure;
        this.nbHeuresRestantes = nbHeureRestante;
        this.nbHeuresFaites = nbHeureFaites;
        this.montant = montant;
    //this.montant =  avion.getTauxHoraire() * (double)nbHeure;  
        //titulaire.getCompte().debiterCompte(montant);
    }
    
    public ForfaitHeure(Membre titulaire, Avion avion, int nbHeure, int nbHeureRestante, int nbHeureFaites, double montant){
         this.titulaire = Objects.requireNonNull(titulaire, "membre null");
        this.avion = Objects.requireNonNull(avion, "avion null");
        this.nbHeure = nbHeure;
        this.nbHeuresRestantes = nbHeureRestante;
        this.nbHeuresFaites = nbHeureFaites;
        this.montant = montant;
    }
    
    public Membre getTitulaire(){
        return titulaire;
    }
    
    public int getNumero(){
        return numero;
    }
    
    public Avion getAvion(){
        return avion;
    }
    
    public int getNbheure(){
        return nbHeure;
    }
    
    public double getMontant(){
        return montant;
    }
    
    public int getNbHeuresRestante(){
        return nbHeuresRestantes;      
    }
    
    public int getNbHeuresFaites(){
        return nbHeuresFaites;
    }
    
    public void setNbHeuresRestante(){ // Mettre à jour les heures restantes du forfait
        if (nbHeuresRestantes >= nbHeuresFaites){
            this.nbHeuresRestantes -= nbHeuresFaites;
        }
        
    }
    
    public void AjouterNbHeuresFaites(int nbHeureF){ // Incrémente le nombre d'heures faites
        this.nbHeuresFaites += nbHeureF;
    }
}

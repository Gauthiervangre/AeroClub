package domaine;

import donnees.DaoCompte;
import donnees.DaoMembre;

public class Membre{
        private int numero;
	private String nom;
	private String prenom;
	private String adresse;
	private String ville;
	private String cp;
	private String tel;
	private String portable;
	private String mail;
	private String dateNaissance;
	private String lieuNaissance;
	private String profession;
	private String identifiant;
	private String admin;
        private Compte monCompte;
        DaoCompte dao = new DaoCompte("jdbc:postgresql://192.168.56.102/AeroClub", "pggauthier", "root");
	
	public Membre(){
	}
	
	public Membre(String pnom, String pprenom, String padresse, String pville, String pcp, String ptel, String pportable, String pmail, String pdate, String plieu, String pprofession, String pidentifiant, String padmin){
		this.nom = pnom;
		this.prenom=pprenom;
		this.adresse = padresse;
		this.ville = pville;
		this.cp = pcp;
		this.tel=ptel;
		this.portable = pportable;
		this.mail = pmail;
		this.dateNaissance =pdate;
		this.lieuNaissance = plieu;
		this.profession = pprofession;
		this.admin = padmin;
		this.identifiant = pidentifiant;
		
	}
        
        public Membre(int numero, String pnom, String pprenom, String padresse, String pville, String pcp, String ptel, String pportable, String pmail, String pdate, String plieu, String pprofession, String pidentifiant, String padmin){
                this(pnom, pprenom, padresse, pville, pcp, ptel, pportable, pmail, pdate, plieu, pprofession, pidentifiant, padmin);
                this.numero = numero;
	}
	
	//Declaration des getters
        public Compte getCompte(){
            return dao.litCompteDunMembre(numero);
        }
        
        public int getNumero(){
            return numero;
        }
	public String getNom(){
		return this.nom;
	}
	public String getPrenom(){
		return this.prenom;
	}
	public String getAdresse(){
		return this.adresse;
	}	
	public String getVille(){
		return this.ville;
	}
	public String getCp(){
		return this.cp;
	}
	public String getTel(){
		return this.tel;
	}
	public String getPortable(){
		return this.portable;
	}
	public String getMail(){
		return this.mail;
	}
	public String getProfession(){
		return this.profession;
	}
	public String getDate(){
	   return this.dateNaissance;
	   }
	public String getLieu(){
	   return this.lieuNaissance;
	 }
	 public String getIdentifiant(){
	   return this.identifiant;
	 }
	 public String getAdmin(){
	   return this.admin;
	 }
	
	
}
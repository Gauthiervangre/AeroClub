package domaine;

import donnees.DaoCompte;
import donnees.DaoForfait;
import donnees.DaoMembre;
import donnees.DaoVol;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;

public class Membre{
        private int numero;
	private String nom;
	private String prenom;
	private String adresse;
	private String ville;
	private String cp;
	private String tel;
	private String portable;
	private String mail;
	private String dateNaissance;
	private String lieuNaissance;
	private String profession;
	private Connecter identifiants;
	private String admin;
        private Compte monCompte;
        DaoCompte dao = new DaoCompte("jdbc:postgresql://192.168.190.21/AeroClub", "aeroclub", "root");
        ArrayList<Vol> mesVols;
        ArrayList<ForfaitHeure> mesForfaits;

	
	public Membre(){
	}
	
	public Membre(String pnom, String pprenom, String padresse, String pville, String pcp, String ptel, String pportable, String pmail, String pdate, String plieu, String pprofession, Connecter ids, String padmin){
		this.nom = pnom;
		this.prenom=pprenom;
		this.adresse = padresse;
		this.ville = pville;
		this.cp = pcp;
		this.tel=ptel;
		this.portable = pportable;
		this.mail = pmail;
		this.dateNaissance =pdate;
		this.lieuNaissance = plieu;
		this.profession = pprofession;
		this.admin = padmin;
		this.identifiants = ids;
		
	}
        
        public Membre(int numero, String pnom, String pprenom, String padresse, String pville, String pcp, String ptel, String pportable, String pmail, String pdate, String plieu, String pprofession, Connecter ids, String padmin){
                this(pnom, pprenom, padresse, pville, pcp, ptel, pportable, pmail, pdate, plieu, pprofession, ids, padmin);
                this.numero = numero;
	}
	
	//Declaration des getters
        public Compte getCompte() throws GeneralSecurityException, IOException{
            return dao.litCompteDunMembre(numero);
        }
        
        public int getNumero(){
            return numero;
        }
	public String getNom(){
		return this.nom;
	}
	public String getPrenom(){
		return this.prenom;
	}
	public String getAdresse(){
		return this.adresse;
	}	
	public String getVille(){
		return this.ville;
	}
	public String getCp(){
		return this.cp;
	}
	public String getTel(){
		return this.tel;
	}
	public String getPortable(){
		return this.portable;
	}
	public String getMail(){
		return this.mail;
	}
	public String getProfession(){
		return this.profession;
	}
	public String getDate(){
	   return this.dateNaissance;
	   }
	public String getLieu(){
	   return this.lieuNaissance;
	 }
	 public Connecter getIdentifiants(){
	   return this.identifiants;
	 }
	 public String getAdmin(){
	   return this.admin;
	 }
	
        public ArrayList<Vol> getMesVols() throws GeneralSecurityException, IOException{
             DaoVol daoV = new DaoVol("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
             mesVols = new ArrayList<>();
             mesVols = daoV.litVolsDunMembre(numero);
             return mesVols;
        }
        
        public ArrayList<ForfaitHeure> getMesForfaits() throws GeneralSecurityException, IOException{
            DaoForfait daoF = new DaoForfait("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
            mesForfaits = new ArrayList<>();
            mesForfaits = daoF.litforfaitsDunMembre(numero);
            return mesForfaits;
        }
	
}
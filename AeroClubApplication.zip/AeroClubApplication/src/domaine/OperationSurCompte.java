/*
-----------------------------------------------------------TABLE OPERATIONS A FAIRE------------------------------------------------------------
 */
package domaine;

import domaine.Membre;
import java.sql.Date;
import donnees.DaoOperation;

/**
 *
 * @author vangr
 */
public class OperationSurCompte {
    private int numero;
    private int numerotype;
    private double montant;
    private String date;
    private Membre membre;
    private String libelle;
    private String detail;
  
    
    public OperationSurCompte(int numerotype, double montant, String date, Membre membre, String detail){
        this.numerotype = numerotype;
        this.montant = montant;
        this.date = date;
        this.membre = membre;
        this.detail = detail;
    }
    
    public OperationSurCompte(int numero, int numerotype, double montant, String date, Membre membre, String detail){
        this(numerotype, montant, date, membre, detail);
        this.numero = numero;
    }
    
    public OperationSurCompte(int numero, String libelle, double montant, String date, Membre membre, String detail){
        this.numero = numero;
        this.libelle = libelle;
        this.montant = montant;
        this.date = date;
        this.membre = membre;
        this.detail = detail;
    }
    
    public int getNumeroType(){
        return numerotype;
    }
    
    public double getMontant(){
        return montant;
    }
    
    public String getLibelle(){
        return libelle;
    }
    
    public String getDate(){
        return date;
    }
    
    public int getNumero(){
        return numero;
    }
    
    public Membre getMembre(){
        return membre;
    }
    
    public String getDetail(){
        return detail;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package domaine;

/**
 *
 * @author gauthier.vangre
 */
public class VolForfait extends Vol{
   private ForfaitHeure leforfait;

    public VolForfait(Membre participant, Instructeur instructeur, Avion avion, String datevol, int duree, ForfaitHeure leforfait) {
        super(participant, instructeur, avion, datevol, duree);
        this.leforfait = leforfait;
    }
    
    public VolForfait(int numero, Membre participant, Instructeur instructeur, Avion avion, String datevol, int duree, ForfaitHeure leforfait) {
        super(numero,participant, instructeur, avion, datevol, duree);
        this.leforfait = leforfait;
    }
   
    public ForfaitHeure getLeForfait(){
        return leforfait;
    }
   
    
}

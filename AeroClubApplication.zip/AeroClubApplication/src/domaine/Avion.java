package domaine;

public class Avion{

private int numero;
private String type;
private String immatriculation;
public double tauxhoraire;

public Avion()
{
    
}

public Avion(String ptype, String pImmatriculation, Double tauxH){
        this.type = ptype;
	this.immatriculation = pImmatriculation;
        this.tauxhoraire = tauxH;
}

public Avion(int numero, String ptype, String pImmatriculation, Double tauxH){
	this(ptype, pImmatriculation, tauxH);
        this.numero = numero;
}


public String getType(){
	return this.type;
}

public String getImmatriculation(){
	return this.immatriculation;
}

public Double getTauxHoraire(){
    return tauxhoraire;
}

public int getNumero(){
    return numero;
}

}
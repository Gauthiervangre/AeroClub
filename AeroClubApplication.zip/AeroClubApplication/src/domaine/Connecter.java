package domaine;


public class Connecter
{
    private String identifiant;
    private String mdp;
    /**
     * Constructor for objects of class Connection
     */
    public Connecter()
    {
    }
     public Connecter(String pIdentifiant, String pMdp)
    {
        this.identifiant = pIdentifiant;
        this.mdp = pMdp;
    }
    public String getIdentifiant()
    {
        return this.identifiant;
    }
    public String getMdp()
    {
        return this.mdp;
    }
}

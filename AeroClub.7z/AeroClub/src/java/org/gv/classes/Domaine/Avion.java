package org.gv.classes.Domaine;

public class Avion{

private int numero;
private String type;
private String immatriculation;
private double tauxHoraire;

public Avion()
{   
}

public Avion(int numero, String ptype, String pImmatriculation, double tauxHoraire){
        this.numero = numero;
        this.type = ptype;
	this.immatriculation = pImmatriculation;
        this.tauxHoraire = tauxHoraire;
}

public String getType(){
	return this.type;
}

public String getImmatriculation(){
	return this.immatriculation;
}

public double getTauxHoraire(){
    return tauxHoraire;
}

public int getNumero(){
    return numero;
}

}

/*
-----------------------------------------------------------TABLE COMPTE A FAIRE------------------------------------------------------------
 */
package org.gv.classes.Domaine;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.gv.classes.Donnees.DaoCompte;
import org.gv.classes.Donnees.DaoOperation;

/**
 *
 * @author vangr
 */
public class Compte {
    private int numero;
    private double solde;
    private Membre titulaire;
    DaoCompte dao = new DaoCompte("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
    DaoOperation daoO = new DaoOperation("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
    ArrayList<OperationSurCompte> mesOperations;

    
    public Compte(int numero, Membre titulaire, double solde){
        this.numero = numero;
        this.titulaire = Objects.requireNonNull(titulaire, "Membre null");
        this.solde = solde;
    }
    
    public int getNumero(){
        return numero;
    }
    
    public double getSolde(){
        return solde;
    }
    
    public ArrayList<OperationSurCompte> getMesOperations(){
            DaoOperation dao = new DaoOperation("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
            mesOperations = new ArrayList<>();
        try {
            mesOperations = dao.toutesLesOperationsDunMembre(titulaire.getNumero());
        } catch (GeneralSecurityException ex) {
            Logger.getLogger(Compte.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Compte.class.getName()).log(Level.SEVERE, null, ex);
        }
            return mesOperations;
    }
    
    public Membre getTitulaire(){
        return titulaire;
    }
    
    public void ajouterOperation(OperationSurCompte operation){
        daoO.ajouterOperation(operation);
    }
    
    public void crediterCompte(double montant, OperationSurCompte operation){
        if (montant > 0){
            dao.crediter(this.getNumero(), montant);
            ajouterOperation(operation);
        }
    }
    
    public void debiterCompte(double montant, OperationSurCompte operation){
        if (montant >0 && montant <= solde){
            dao.debiter(this.getNumero(), montant);
            ajouterOperation(operation);
        }
    }
    
   
    
}

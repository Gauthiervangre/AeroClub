/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.classes.Domaine;

/**
 *
 * @author vangr
 */

public class Instructeur{
        private int numero;
	private String nom;
	private String prenom;
	private String adresse;
	private String ville;
	private String cp;
	private String tel;
	private String portable;
	private String mail;
	private String fax;
        private static int tauxHoraire = 25;


	public Instructeur(){

	}

	public Instructeur(String pnom, String pprenom, String padresse, String pville){
		this.nom = pnom;
		this.prenom=pprenom;
		this.adresse = padresse;
		this.ville = pville;
	
	}
	
	public Instructeur(int numero,String pnom, String pprenom, String padresse, String pville, String pcp, String ptel, String pportable, String pmail, String pfax){
                this(pnom, pprenom, padresse, pville);
                this.numero = numero;
		this.cp = pcp;
		this.tel=ptel;
		this.portable = pportable;
		this.mail = pmail;
		this.fax = pfax;
	}
	
		//Declaration des getter
        
        public int getNumero(){
            return numero;
        }
        
	public String getNom(){
		return this.nom;
	}
	public String getPrenom(){
		return this.prenom;
	}
	public String getAdresse(){
		return this.adresse;
	}	
	public String getVille(){
		return this.ville;
	}
	public String getCp(){
		return this.cp;
	}
	public String getTel(){
		return this.tel;
	}
	public String getPortable(){
		return this.portable;
	}
	public String getMail(){
		return this.mail;
	}
	public String getFax(){
		return this.fax;
	}
        
        public static int getTauxHoraire(){
            return tauxHoraire;
        }
        
        public void setTauxHoraire(int tauxHoraire){
            Instructeur.tauxHoraire = tauxHoraire;          
        }
	
}
package org.gv.classes.Domaine;

import java.util.ArrayList;
import java.util.Objects;
import org.gv.classes.Donnees.DaoCompte;
import org.gv.classes.Donnees.DaoForfait;
import org.gv.classes.Donnees.DaoVol;

public class Membre{
        private int numero;
	private String nom;
	private String prenom;
	private String adresse;
	private String ville;
	private String cp;
	private String tel;
	private String portable;
	private String mail;
	private String dateNaissance;
	private String lieuNaissance;
	private String profession;
	private String identifiant;
	private String admin;
        private Compte monCompte;
        ArrayList<Vol> mesVols;
        ArrayList<ForfaitHeure> mesForfaits;

        
	public Membre(){
	}
        
	public Membre(int numero, String pnom, String pprenom, String padresse, String pville, String pcp, String ptel, String pportable, String pmail, String pdate, String plieu, String pprofession, String pidentifiant, String padmin){
		this.numero = numero;
                this.nom = pnom;
		this.prenom=pprenom;
		this.adresse = padresse;
		this.ville = pville;
		this.cp = pcp;
		this.tel=ptel;
		this.portable = pportable;
		this.mail = pmail;
		this.dateNaissance =pdate;
		this.lieuNaissance = plieu;
		this.profession = pprofession;
		this.admin = padmin;
		this.identifiant = pidentifiant;
	}
        
        public Compte getCompte(){
            DaoCompte dao = new DaoCompte("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
            monCompte = dao.litCompteDunMembre(this.getNumero());
            return monCompte;
        }
        
        public ArrayList<Vol> getMesVols(){
             DaoVol daoV = new DaoVol("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
             mesVols = new ArrayList<>();
             mesVols = daoV.litVolsDunMembre(numero);
             return mesVols;
        }
        
        public ArrayList<ForfaitHeure> getMesForfaits(){
            DaoForfait daoF = new DaoForfait("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
            mesForfaits = new ArrayList<>();
            mesForfaits = daoF.litforfaitsDunMembre(numero);
            return mesForfaits;
        }
        
	//Declaration des getters
        
        public int getNumero(){
            return numero;
        }
        
	public String getNom(){
		return this.nom;
	}
	public String getPrenom(){
		return this.prenom;
	}
	public String getAdresse(){
		return this.adresse;
	}	
	public String getVille(){
		return this.ville;
	}
	public String getCp(){
		return this.cp;
	}
	public String getTel(){
		return this.tel;
	}
	public String getPortable(){
		return this.portable;
	}
	public String getMail(){
		return this.mail;
	}
	public String getProfession(){
		return this.profession;
	}
	public String getDate(){
	   return this.dateNaissance;
	   }
	public String getLieu(){
	   return this.lieuNaissance;
	 }
	 public String getIdentifiant(){
	   return this.identifiant;
	 }
	 public String getAdmin(){
	   return this.admin;
	 }
         
         public void ajouterForfait(ForfaitHeure forfait, OperationSurCompte operation){
         DaoForfait dao = new DaoForfait("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
         dao.ajouterforfait(forfait);
         this.getCompte().debiterCompte(forfait.getMontant(), operation);
         }
	
	
}
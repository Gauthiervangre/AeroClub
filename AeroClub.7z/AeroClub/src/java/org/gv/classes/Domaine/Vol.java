/*
-----------------------------------------------------------TABLE VOL A FAIRE------------------------------------------------------------
 */
package org.gv.classes.Domaine;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author vangr
 */
public class Vol {
    private int numero;
    private String dateVol;
    private int duree; // en heures
    private Avion avion;
    private Membre participant;
    private Instructeur instructeur;
    
    public Vol(int numero, Membre participant, Instructeur instructeur, Avion avion, String dateVol, int duree){
        this.numero = numero;
        this.participant = Objects.requireNonNull(participant, "membre null");
        this.avion = avion;
        this.instructeur = instructeur;
        this.dateVol = dateVol;
        this.duree = duree;
    }
    
    public Vol( Membre participant, Instructeur instructeur, Avion avion, String dateVol, int duree){
        this.participant = Objects.requireNonNull(participant, "membre null");
        this.avion = avion;
        this.instructeur = instructeur;
        this.dateVol = dateVol;
        this.duree = duree;
    }

    public int getNumero(){
        return numero;
    }   
    
    public String getDateVol() {
        return dateVol;
    }

    public int getDuree() {
        return duree;
    }

    public Avion getAvion() {
        return avion;
    }

    public Membre getParticipant() {
        return participant;
    }
    
    public Instructeur getInstructeur(){
        return instructeur;
    }
    
    
    
    
}

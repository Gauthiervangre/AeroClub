/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.classes.Domaine;

/**
 *
 * @author vangr
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author vangr
 */

//ACHETER UN VOL AVEC UN FORFAIT, LES HEURES Y SONT DECOMPTEES

/*public class VolForfait extends Vol {  
    private ForfaitHeure forfait;
    
    public VolForfait(Membre participant, Avion avion, Date dateVol, int duree , ForfaitHeure forfait){
        super(participant, avion, dateVol, duree);
        this.forfait = Objects.requireNonNull(forfait, "forfaitHeure null");
        //participant.setMesVols(this);
        
        forfait.AjouterNbHeuresFaites(duree);
        forfait.setNbHeuresRestante();
    }
    
    public ForfaitHeure getForfait(){
        return forfait;
    }
    
    
    
}
*/
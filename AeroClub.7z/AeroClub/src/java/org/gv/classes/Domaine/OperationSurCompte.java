/*
-----------------------------------------------------------TABLE OPERATIONS A FAIRE------------------------------------------------------------
 */
package org.gv.classes.Domaine;

import java.util.Date;
import static java.sql.JDBCType.TIME;
import java.sql.Time;
import static java.sql.Types.TIME;
import org.gv.classes.Donnees.DaoOperation;

/**
 *
 * @author vangr
 */
public class OperationSurCompte {
    private int numero;
    private int numerotype;
    private double montant;
    private Date date;
    private Membre membre;
    private String libelle;
    private String detail;
    private Time temps;
  
    
    public OperationSurCompte(int numerotype, double montant, Date date, Membre membre, String detail, Time temps){
        this.numerotype = numerotype;
        this.montant = montant;
        this.date = date;
        this.membre = membre;
        this.detail = detail;
        this.temps = temps;
    }
    
    public OperationSurCompte(int numero, int numerotype, double montant, Date date, Membre membre, String detail, Time temps){
        this(numerotype, montant, date, membre, detail, temps);
        this.numero = numero;
    }
    
    public OperationSurCompte(int numero, String libelle, double montant, Date date, Membre membre, String detail, Time temps){
        this.numero = numero;
        this.libelle = libelle;
        this.montant = montant;
        this.date = date;
        this.membre = membre;
        this.detail = detail;
        this.temps = temps;
    }
    
    public int getNumeroType(){
        return numerotype;
    }
    
    public double getMontant(){
        return montant;
    }
    
    public String getLibelle(){
        return libelle;
    }
    
    public Date getDate(){
        return date;
    }
    
    public int getNumero(){
        return numero;
    }
    
    public Membre getMembre(){
        return membre;
    }
    
    public String getDetail(){
        return detail;
    }
    
    public Time getTemps(){
        return temps;
    }
    
}

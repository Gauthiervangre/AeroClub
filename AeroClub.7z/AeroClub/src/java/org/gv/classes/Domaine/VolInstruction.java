/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.classes.Domaine;

import java.util.Date;

/**
 *
 * @author vangr
 */
public class VolInstruction extends VolForfait{
    private Instructeur instructeur;
    private double montant;
    
    public VolInstruction(Membre participant, Avion avion,  Date dateVol, int duree, ForfaitHeure forfait, Instructeur instructeur){
        super(participant, avion, dateVol, duree, forfait);
        this.instructeur = instructeur;
        this.montant = duree * Instructeur.getTauxHoraire();
    }
    
    public Instructeur getInstructeur(){
        return instructeur;
    }
    
    public double getMontant(){
        return montant;
    }
    
}

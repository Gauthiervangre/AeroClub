/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.classes.Domaine;


import java.util.Date;

/**
 *
 * @author vangr
 */
// ACHETER UN VOL DIRECTEMENT SANS FORFAIT
/*public class VolSansForfait extends Vol {
    private double montant;
    
    public VolSansForfait(Membre participant, Avion avion, Date dateVol, int duree, double montant) throws ExceptionCompte{
        super(participant, avion, dateVol, duree);
        this.montant = avion.getTauxHoraire() *(double) duree;
        participant.getCompte().debiterCompte(montant);
    }
    
    public double getMontantVol(){
        return montant;
    }
}*/

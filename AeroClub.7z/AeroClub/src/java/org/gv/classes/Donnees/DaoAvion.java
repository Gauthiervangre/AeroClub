package org.gv.classes.Donnees;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import org.postgresql.Driver;
import org.gv.classes.Domaine.Avion;

	public class DaoAvion{
		PreparedStatement prep;
		Statement stat;
		Connection connection;
		String chemin;//("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
                String user;
                String pass;
		ArrayList<Avion> listAvion;
		Avion avion;
		
		
		public DaoAvion(String pChemin, String puser, String ppass){
                    try{
                        this.chemin = pChemin;
                        this.user=puser;
                        this.pass = ppass;
                        Class.forName("org.postgresql.Driver");
                        this.connection = DriverManager.getConnection(pChemin, puser, ppass);
                    }
                    catch(ClassNotFoundException eX){
                        System.out.println("Class non trouvée");
                        eX.printStackTrace();
                    }
                    catch(SQLException sX){
                        System.out.println("SQL error création objet");
                        sX.printStackTrace();
                    }
                    if (this.connection!=null){
                        System.out.println("Connexion réussie");
                     }
                    else{
                         System.out.println("Connexion échouée");  
                    }
		}
		
		public Avion litAvion(String immatriculation){
			try{
                            this.prep = this.connection.prepareStatement("Select * FROM AVION WHERE immatriculation =?");
                            this.prep.setString(1,immatriculation);
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                     avion = new Avion(res.getInt("numero"), res.getString("type"), res.getString("IMMATRICULATION"), res.getDouble("tauxhoraire"));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire avion");
                            eX.printStackTrace();
			}
			return avion;
		}
                
                public Avion litAvionNumero(int numero){
			try{
                            this.prep = this.connection.prepareStatement("Select * FROM AVION WHERE numero =?");
                            this.prep.setInt(1,numero);
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                     avion = new Avion(res.getInt("numero"), res.getString("type"), res.getString("IMMATRICULATION"), res.getDouble("tauxhoraire"));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire avion");
                            eX.printStackTrace();
			}
			return avion;
		}

		public void ajouterAvion(Avion avion){
			try{
                            this.prep = this.connection.prepareStatement("INSERT INTO AVION (TYPE,IMMATRICULATION) VALUES (?,?)");
                            this.prep.setString(1, avion.getType());
                            this.prep.setString(2, avion.getImmatriculation());
                            this.prep.execute();	
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error ajouter avion");
                            eX.printStackTrace();
			}
		}

		public void supprimerAvion(String immatriculation){
			try{
				this.prep = this.connection.prepareStatement("DELETE FROM AVION WHERE immatriculation =?");
				this.prep.setString(1, immatriculation);
				this.prep.execute();
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error supprimer avion");
                            eX.printStackTrace();
			}
		}

		public ArrayList<Avion> tousLesAvions(){
			try{
                            listAvion = new ArrayList();
                            this.prep = this.connection.prepareStatement("SELECT * FROM AVION");
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                listAvion.add(new Avion(res.getInt("numero"), res.getString("TYPE"), res.getString("IMMATRICULATION"), res.getDouble("tauxhoraire")));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lister tous les avions");
                            eX.printStackTrace();
			}
			return listAvion;
		}

}
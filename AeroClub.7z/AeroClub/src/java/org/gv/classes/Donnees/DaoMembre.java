package org.gv.classes.Donnees;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import java.security.GeneralSecurityException;
import org.postgresql.Driver;
import org.gv.classes.Domaine.Membre;

public class DaoMembre{
    PreparedStatement prep;
    Statement stat;
    Connection connection;
    String chemin;//("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
    String user;
    String pass;
    ArrayList<Membre> listMembre;
    Membre membre;
    DaoConnexion dao = new DaoConnexion("jdbc:postgresql://192.168.56.102/AeroClub", "pggauthier", "root");
	
	public DaoMembre(String pChemin,String puser, String ppass){
            try{
                this.chemin = pChemin;
                this.user=puser;
                this.pass = ppass;
                Class.forName("org.postgresql.Driver");
                this.connection = DriverManager.getConnection(pChemin, puser, ppass);
            }
            catch(ClassNotFoundException eX){
                System.out.println("Class non trouvée");
                eX.printStackTrace();
            }
            catch(SQLException sX){
                System.out.println("SQL error création objet");
                sX.printStackTrace();
            }
            if (this.connection!=null){
                System.out.println("Connexion réussie");
            }
            else{
              System.out.println("Connexion échouée");  
            }
        }


	public Membre litMembre(int numero) throws GeneralSecurityException, IOException{
		try{
                    this.prep = this.connection.prepareStatement("SELECT * FROM MEMBRE WHERE numero = ?");
                    this.prep.setLong(1, numero);
                    ResultSet res = this.prep.executeQuery();
                    while(res.next()){
                        membre = new Membre(numero, res.getString("NOM"), res.getString("PRENOM"), res.getString("ADRESSE"), res.getString("VILLE"), res.getString("CP"),res.getString("TEL"), res.getString("PORTABLE"), res.getString("MAIL"), res.getString("DATENAISSANCE"), res.getString("LIEUNAISSANCE"), res.getString("PROFESSION"), dao.litConnection(res.getString("identifiant")), res.getString("admin"));
                    }
		}
		catch (SQLException eX)
		{
                    System.out.println("SQL error lire membre");
                    eX.printStackTrace();
		}
		return membre;
	}
	
	public void ajouterMembre(Membre membre){
		try{
		
			this.prep = this.connection.prepareStatement("INSERT INTO MEMBRE (NOM, PRENOM, ADRESSE, CP, VILLE, TEL, PORTABLE, MAIL, datenaissance, lieunaissance, PROFESSION, identifiant, admin) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
			this.prep.setString(1, membre.getNom());
			this.prep.setString(2, membre.getPrenom());
			this.prep.setString(3, membre.getAdresse());
			this.prep.setString(4, membre.getCp());
			this.prep.setString(5, membre.getVille());
			this.prep.setString(6, membre.getTel());
			this.prep.setString(7, membre.getPortable());
			this.prep.setString(8, membre.getMail());
			this.prep.setString(9,membre.getDate());
			this.prep.setString(10, membre.getLieu());
			this.prep.setString(11, membre.getProfession());
                        this.prep.setString(12, membre.getIdentifiants().getIdentifiant());
                        this.prep.setString(13, membre.getAdmin());
			this.prep.execute();
		}
		catch (SQLException eX)
		{
		  System.out.println("SQL error ajouter membre");
                  eX.printStackTrace();
		}
	}
        
        public void modifierMembre(int numero,String nom, String prenom, String adresse, String cp, String ville, String tel, String portable, String mail, String date, String lieu, String profession){
            try{
			this.prep = this.connection.prepareStatement("UPDATE MEMBRE SET NOM = ?, PRENOM = ?, ADRESSE= ?, CP= ?, VILLE= ?, TEL= ?, PORTABLE= ?, MAIL= ?, datenaissance= ?, lieunaissance= ?, PROFESSION= ? WHERE numero = ?");
			this.prep.setString(1, nom);
			this.prep.setString(2, prenom);
			this.prep.setString(3, adresse);
			this.prep.setString(4, cp);
			this.prep.setString(5, ville);
			this.prep.setString(6, tel);
			this.prep.setString(7, portable);
			this.prep.setString(8, mail);
			this.prep.setString(9, date);
			this.prep.setString(10, lieu);
			this.prep.setString(11, profession);
                        this.prep.setInt(12, numero);
			this.prep.execute();
		}
		catch (SQLException eX)
		{
		  System.out.println("SQL error ajouter membre");
                  eX.printStackTrace();
		}
        }
        
	public void supprimerMembre(int numero){
		try{
		
			this.prep = this.connection.prepareStatement("DELETE FROM MEMBRE WHERE numero= ?");
			this.prep.setLong(1, numero);
			this.prep.execute();
		}
		catch (SQLException eX)
		{
		  System.out.println("SQL error supprimer membre");
                  eX.printStackTrace();
		}
	}
	
	public ArrayList<Membre> tousLesMembres() throws GeneralSecurityException, IOException{
	 listMembre = new ArrayList();
            try{
                this.prep=this.connection.prepareStatement("SELECT * FROM MEMBRE where admin = ?");
                this.prep.setString(1, "0");
                ResultSet res = this.prep.executeQuery();
                while (res.next()){
                listMembre.add(new Membre(res.getInt("numero"), res.getString("NOM"), res.getString("PRENOM"), res.getString("ADRESSE"), res.getString("VILLE"), res.getString("cp"), res.getString("tel"), res.getString("portable"),res.getString("mail"),res.getString("datenaissance"), res.getString("lieunaissance"), res.getString("profession"), dao.litConnection(res.getString("identifiant")), res.getString("admin")));
                }
            }
            catch (SQLException eX){
		     System.out.println("SQL error lister membre");
                  eX.printStackTrace();
            }
            return listMembre;
	}
        

}

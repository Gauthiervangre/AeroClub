package org.gv.classes.Donnees;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import java.security.GeneralSecurityException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.gv.classes.Domaine.Compte;
import org.gv.classes.Domaine.Connexion;
import org.postgresql.Driver;
import org.gv.classes.Domaine.Instructeur;
import org.gv.classes.Domaine.Membre;
import org.gv.classes.Domaine.*;

public class DaoConnexion{
	PreparedStatement prep;
	Statement stat;
	Connection connection;
	String chemin; //("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
        String user;
        String pass;
        Compte compte;
        Cryption cryption = new Cryption();

	public DaoConnexion(String pChemin, String puser, String ppass){
            try{
                this.chemin = pChemin;
                this.user = puser;
                this.pass = ppass;
                Class.forName("org.postgresql.Driver");
                this.connection = DriverManager.getConnection(pChemin, puser, ppass);
            }
            catch(ClassNotFoundException eX){
                System.out.println("Class non trouvée");
                eX.printStackTrace();
            }
            catch(SQLException sX){
                System.out.println("SQL error création objet");
                sX.printStackTrace();
            }
            if (this.connection!=null){
                System.out.println("Connexion réussie");
            }
            else{
                System.out.println("Connexion échouée");  
            }
        }

	public ArrayList<Connexion> toutesLesConnexions(){
            ArrayList<Connexion> list = new ArrayList<>();
            try{
                this.prep = this.connection.prepareStatement("SELECT * FROM connexion");
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                        list.add(new Connexion(res.getString("identifiant"), res.getString("mdp")));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error lire instructeur");
                eX.printStackTrace();
            }
            return list;
        }
        
        public ArrayList<Connexion> toutesLesConnexionsMembre() throws GeneralSecurityException, IOException{
            ArrayList<Connexion> list = new ArrayList<>();
            try{
                this.prep = this.connection.prepareStatement("SELECT * FROM connexion INNER JOIN membre ON membre.identifiant = connexion.identifiant WHERE admin = ?");
                this.prep.setString(1, "0");
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                        list.add(new Connexion(res.getString("identifiant"), cryption.decrypt(res.getString("mdp"))));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error lire instructeur");
                eX.printStackTrace();
            }
            return list;
        }
        
        public Membre LireMembreSelonIdentifiant(String identifiant){
            Membre membre = null;
            try{
                this.prep = this.connection.prepareStatement("SELECT * FROM membre where identifiant = ?");
                this.prep.setString(1, identifiant);
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                        membre = new Membre(res.getInt("numero"), res.getString("NOM"), res.getString("PRENOM"), res.getString("ADRESSE"), res.getString("VILLE"), res.getString("CP"),res.getString("TEL"), res.getString("PORTABLE"), res.getString("MAIL"), res.getString("DATENAISSANCE"), res.getString("LIEUNAISSANCE"), res.getString("PROFESSION"), res.getString("identifiant"), res.getString("admin"));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error trouver membre grâce à son identifiant");
                eX.printStackTrace();
            }
            return membre;
        }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.vols;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.gv.classes.Domaine.Membre;
import org.gv.classes.Domaine.Vol;
import org.gv.classes.Domaine.VolForfait;
import org.gv.classes.Donnees.DaoVol;
import org.gv.classes.Donnees.DaoVolForfait;

/**
 *
 * @author eleve
 */
public class mesVols extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, GeneralSecurityException {
        DaoVol daoV = new DaoVol("jdbc:postgresql://192.168.190.21:5432/AeroClub", "aeroclub", "root");
        DaoVolForfait daoF = new DaoVolForfait("jdbc:postgresql://192.168.190.21:5432/AeroClub", "aeroclub", "root");
        HttpSession session = request.getSession();
        Membre moi = (Membre) session.getAttribute("moi");
        ArrayList<Vol> list = new ArrayList<>();
        ArrayList<VolForfait> list2 = new ArrayList<>();
        list = daoV.litVolsDunMembre(moi.getNumero());
        list2 = daoF.litVolsDunMembre(moi.getNumero());
        session.setAttribute("vols", list);
        session.setAttribute("volsforfaits", list2);
        
        this.getServletContext().getRequestDispatcher("/mesVols.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (GeneralSecurityException ex) {
            Logger.getLogger(mesVols.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (GeneralSecurityException ex) {
            Logger.getLogger(mesVols.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.forfaits;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.gv.classes.Domaine.Avion;
import org.gv.classes.Domaine.ForfaitHeure;
import org.gv.classes.Domaine.Membre;
import org.gv.classes.Domaine.OperationSurCompte;
import org.gv.classes.Donnees.DaoAvion;
import org.gv.classes.Donnees.DaoForfait;
import org.gv.classes.Donnees.DaoMembre;

/**
 *
 * @author eleve
 */
public class acheter_forfait extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, GeneralSecurityException {
        String immatriculation = request.getParameter("immatriculation");
        int nbheure = Integer.parseInt((String) request.getParameter("nbheure"));
        HttpSession session = request.getSession();
        Membre moi = (Membre) session.getAttribute("moi");
        
        DaoAvion dao = new DaoAvion("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
        Avion avion = dao.litAvion(immatriculation); // AVION CHOISI
        double montant = nbheure * avion.getTauxHoraire(); //MONTANT DU FORFAIT
        
        // date 
        Date aujourdhui = Calendar.getInstance().getTime();
        DaoForfait daoF = new DaoForfait("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
        
        moi.ajouterForfait(new ForfaitHeure(moi, avion, nbheure, nbheure, 0, montant), new OperationSurCompte(2, montant,  new Date(aujourdhui.getYear(), aujourdhui.getMonth(), aujourdhui.getDate()), moi, "Achat forfait numéro " + String.valueOf(daoF.tousLesforfaits().get(daoF.tousLesforfaits().size() -1).getNumero()), new Time(aujourdhui.getHours(), aujourdhui.getMinutes(), aujourdhui.getSeconds())));
        
        DaoMembre daoM = new DaoMembre("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
        session.setAttribute("moi", daoM.litMembre(moi.getNumero()));
         
        this.getServletContext().getRequestDispatcher("/mesForfaits").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (GeneralSecurityException ex) {
            Logger.getLogger(acheter_forfait.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (GeneralSecurityException ex) {
            Logger.getLogger(acheter_forfait.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

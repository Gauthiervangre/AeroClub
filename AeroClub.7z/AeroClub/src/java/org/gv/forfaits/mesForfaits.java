/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.forfaits;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.gv.classes.Domaine.Avion;
import org.gv.classes.Domaine.ForfaitHeure;
import org.gv.classes.Domaine.Membre;
import org.gv.classes.Donnees.DaoAvion;
import org.gv.classes.Donnees.DaoMembre;

/**
 *
 * @author eleve
 */
public class mesForfaits extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ArrayList<ForfaitHeure> mesForfaits = new ArrayList<>();
        HttpSession session = request.getSession();
        DaoMembre dao = new DaoMembre("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
        Membre moi = (Membre) session.getAttribute("moi");
        session.setAttribute("moi", dao.litMembre(moi.getNumero()));
        
        Membre moiVrai = (Membre) session.getAttribute("moi");
        
        mesForfaits = moiVrai.getMesForfaits();
        session.setAttribute("mesForfaits", mesForfaits);
        
        ////////////////////////////////////////////////////////////////////
        
        
        ArrayList<Avion> tousLesAvions = new ArrayList<>();
        DaoAvion daoA = new DaoAvion("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
        tousLesAvions = daoA.tousLesAvions();
        request.setAttribute("tousLesAvions", tousLesAvions);
        
        this.getServletContext().getRequestDispatcher("/mesForfaits.jsp").forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

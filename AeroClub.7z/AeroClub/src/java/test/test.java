/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import org.gv.classes.Domaine.*;
import org.gv.classes.Donnees.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
 
/**
 *
 * @author eleve
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws GeneralSecurityException, IOException {
       /* 
        compte.debiterCompte(108);
        System.out.println(compte.getTitulaire().getIdentifiant());
        
        
        DaoConnexion dao = new DaoConnexion("jdbc:postgresql://192.168.56.102:5432/AeroClub", "gauthier", "root");
        ArrayList<Connexion> list = dao.toutesLesConnexions();
        System.out.println(list.get(0).getIdentifiant());
        
        DateFormat fd = new SimpleDateFormat("dd-MM-yyyy");
 
    Date aujourdhui = Calendar.getInstance().getTime();
    String dateFormatee = fd.format(aujourdhui);
 
    System.out.println("La Date: " + dateFormatee);
        */
    Date aujourdhui = Calendar.getInstance().getTime();
    System.out.println(aujourdhui);
    
    System.out.println(new Date(aujourdhui.getYear(), aujourdhui.getMonth(), aujourdhui.getDate()));
    System.out.println(new Time(aujourdhui.getHours(), aujourdhui.getMinutes(), aujourdhui.getSeconds()));
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package domaine;

import java.util.Date;


public class Vol {
private int numero;
private String dateVol;
private int duree;
private Avion avion;
private Membre participant;
private Instructeur instructeur;

public Vol(Membre participant, Instructeur instructeur, Avion avion, String datevol, int duree){
    this.participant = participant;
    this.instructeur = instructeur;
    this.avion = avion;
    this.dateVol = datevol;
    this.duree = duree;
}

public Vol(int numero, Membre participant, Instructeur instructeur, Avion avion, String datevol, int duree){
    this(participant, instructeur, avion, datevol, duree);
    this.numero = numero;
}

public int getNumero(){
    return numero;
}

public String getDateVol(){
    return dateVol;
}

public int getDuree(){
    return duree;
}

public Avion getAvion(){
    return avion;
}

public Membre getParticipant(){
    return participant;
}

public Instructeur getInstructeur(){
    return instructeur;
}






}





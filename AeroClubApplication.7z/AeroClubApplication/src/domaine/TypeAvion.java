/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package domaine;

/**
 *
 * @author gauthier.vangre
 */
public class TypeAvion {
    private int numero;
    private String libelle;
    
    public TypeAvion(int numero, String libelle){
        this.numero = numero;
        this.libelle = libelle;
    }
    
    public int getNumero(){
        return numero;
    }
    
    public String getLibelle(){
        return libelle;
    }
}

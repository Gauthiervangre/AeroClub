package domaine;

public class Avion{

private int numero;
private TypeAvion type;
private String immatriculation;
public double tauxhoraire;

public Avion()
{
    
}

public Avion(TypeAvion type, String pImmatriculation, Double tauxH){
        this.type = type;
	this.immatriculation = pImmatriculation;
        this.tauxhoraire = tauxH;
}

public Avion(int numero, TypeAvion ptype, String pImmatriculation, Double tauxH){
	this(ptype, pImmatriculation, tauxH);
        this.numero = numero;
}


public TypeAvion getType(){
	return type;
}

public String getImmatriculation(){
	return immatriculation;
}

public Double getTauxHoraire(){
    return tauxhoraire;
}

public int getNumero(){
    return numero;
}

}
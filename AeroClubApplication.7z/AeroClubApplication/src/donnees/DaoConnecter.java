package donnees;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import org.postgresql.Driver;
import domaine.Avion;
import domaine.Connecter;
import domaine.Cryption;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;

	public class DaoConnecter{
        PreparedStatement prep;
        Statement stat;
        Connection connection;
        String chemin;//("jdbc:postgresql://192.168.56.102:5432/AeroClub", "pggauthier", "root");
        String user;
        String pass;
        ArrayList<Connecter> list;
        Connecter xd;
        Cryption cryption = new Cryption();
		
		public DaoConnecter(String pChemin, String puser, String ppass){
                    try{
                        this.chemin = pChemin;
                        this.user=puser;
                        this.pass = ppass;
                        Class.forName("org.postgresql.Driver");
                        this.connection = DriverManager.getConnection(pChemin, puser, ppass);
                    }
                    catch(ClassNotFoundException eX){
                        System.out.println("Class non trouvée");
                        eX.printStackTrace();
                    }
                    catch(SQLException sX){
                        System.out.println("SQL error création objet");
                        sX.printStackTrace();
                    }
                    if (this.connection!=null){
                        System.out.println("Connexion réussie");
                     }
                    else{
                         System.out.println("Connexion échouée");  
                    }
		}
		public Connecter litConnection(String identifiant) throws GeneralSecurityException, IOException{
			try{
                            this.prep = this.connection.prepareStatement("Select * FROM connexion WHERE identifiant =?");
                            this.prep.setString(1,identifiant);
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                    xd = new Connecter(res.getString("identifiant"), cryption.decrypt(res.getString("mdp")));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lire connection");
                            eX.printStackTrace();
			}
			return xd;
		}

		public void ajouterConnection(Connecter co) throws GeneralSecurityException, UnsupportedEncodingException{
			try{
                            this.prep = this.connection.prepareStatement("INSERT INTO connexion (identifiant, mdp) VALUES (?,?)");
                            this.prep.setString(1, co.getIdentifiant());
                            this.prep.setString(2, cryption.encrypt(co.getMdp()));
                            this.prep.execute();	
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error ajouter connection");
                            eX.printStackTrace();
			}
		}

		public void supprimerConnection(String identifiant){
			try{
				this.prep = this.connection.prepareStatement("DELETE FROM connexion WHERE identifiant=?");
				this.prep.setString(1, identifiant);
				this.prep.execute();
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error supprimer connection");
                            eX.printStackTrace();
			}
		}

		public ArrayList<Connecter> toutesLesConnections() throws GeneralSecurityException, IOException{
			try{
                            list = new ArrayList();
                            this.prep = this.connection.prepareStatement("SELECT * FROM connexion");
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                list.add(new Connecter(res.getString("identifiant"), cryption.decrypt(res.getString("mdp"))));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lister toutes les connections");
                            eX.printStackTrace();
			}
			return list;
		}
                
                public ArrayList<Connecter> tousLesAdmins() throws GeneralSecurityException, IOException{
			try{
                            list = new ArrayList();
                            this.prep = this.connection.prepareStatement("SELECT * FROM connexion INNER JOIN membre ON (connexion.identifiant = membre.identifiant) AND admin = ?");
                            this.prep.setString(1,"1");
                            ResultSet res = this.prep.executeQuery();
                            while(res.next()){
                                list.add(new Connecter(res.getString("identifiant"), cryption.decrypt(res.getString("mdp"))));
                            }
			}
			catch (SQLException eX)
			{
                            System.out.println("SQL error lister tous les admins");
                            eX.printStackTrace();
			}
			return list;
		}
                
                

}
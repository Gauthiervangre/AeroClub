/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.ajax;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.gv.classes.Domaine.Membre;
import org.gv.classes.Domaine.VolForfait;
import org.gv.classes.Donnees.DaoMembre;
import org.gv.classes.Donnees.DaoVolForfait;

/**
 *
 * @author root
 */
public class trievolforfait extends HttpServlet {

DaoVolForfait vol = new DaoVolForfait("jdbc:postgresql://192.168.190.21:5432/AeroClub", "aeroclub", "root");
DaoMembre dao = new DaoMembre("jdbc:postgresql://192.168.190.21:5432/AeroClub", "aeroclub", "root");
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, GeneralSecurityException {
        String valeur = request.getParameter("valeur");
         response.setContentType("text/xml");
        response.setHeader("Cache-Control", "no-cache");
        HttpSession session = request.getSession();
        Membre moi = (Membre) session.getAttribute("moi");
        
        if (valeur.equals("datedesc")){
            ArrayList<VolForfait> list = vol.litVolsDunMembreDateDesc(moi.getNumero());
            ArrayList listRenvoyee = new ArrayList();
            for (VolForfait v : list){
                listRenvoyee.add(v.getNumero());
                listRenvoyee.add(v.getInstructeur().getNumero());
                listRenvoyee.add(v.getInstructeur().getNom());
                listRenvoyee.add(v.getInstructeur().getPrenom());
                listRenvoyee.add(v.getAvion().getNumero());
                listRenvoyee.add(v.getAvion().getImmatriculation());
                listRenvoyee.add(v.getDate());
                listRenvoyee.add(v.getDuree());
                listRenvoyee.add(v.getLeForfait().getNumero());
            }
            response.getWriter().write("<message>"+listRenvoyee+"</message>");
        }
        else if(valeur.equals("dateasc")){
                ArrayList<VolForfait> list = null;
                list = vol.litVolsDunMembreDateAsc(moi.getNumero());
                ArrayList listRenvoyee = new ArrayList();
                for (VolForfait v : list){
                    listRenvoyee.add(v.getNumero());
                    listRenvoyee.add(v.getInstructeur().getNumero());
                    listRenvoyee.add(v.getInstructeur().getNom());
                    listRenvoyee.add(v.getInstructeur().getPrenom());
                    listRenvoyee.add(v.getAvion().getNumero());
                    listRenvoyee.add(v.getAvion().getImmatriculation());
                    listRenvoyee.add(v.getDate());
                    listRenvoyee.add(v.getDuree());
                    listRenvoyee.add(v.getLeForfait().getNumero());
                }
                response.getWriter().write("<message>"+listRenvoyee+"</message>");
        }
        else if (valeur.equals("forfait")){
                 ArrayList<VolForfait> list = null;
                list = vol.litVolsDunMembreOrderedByForfait(moi.getNumero());
                ArrayList listRenvoyee = new ArrayList();
                for (VolForfait v : list){
                    listRenvoyee.add(v.getNumero());
                    listRenvoyee.add(v.getInstructeur().getNumero());
                    listRenvoyee.add(v.getInstructeur().getNom());
                    listRenvoyee.add(v.getInstructeur().getPrenom());
                    listRenvoyee.add(v.getAvion().getNumero());
                    listRenvoyee.add(v.getAvion().getImmatriculation());
                    listRenvoyee.add(v.getDate());
                    listRenvoyee.add(v.getDuree());
                    listRenvoyee.add(v.getLeForfait().getNumero());
                }
                response.getWriter().write("<message>"+listRenvoyee+"</message>");
        }
        else if(valeur.equals("instructeur")){
                ArrayList<VolForfait> list = null;
                list = vol.litVolsDunMembreOrderedByInstructeur(moi.getNumero());
                ArrayList listRenvoyee = new ArrayList();
                for (VolForfait v : list){
                    listRenvoyee.add(v.getNumero());
                    listRenvoyee.add(v.getInstructeur().getNumero());
                    listRenvoyee.add(v.getInstructeur().getNom());
                    listRenvoyee.add(v.getInstructeur().getPrenom());
                    listRenvoyee.add(v.getAvion().getNumero());
                    listRenvoyee.add(v.getAvion().getImmatriculation());
                    listRenvoyee.add(v.getDate());
                    listRenvoyee.add(v.getDuree());
                    listRenvoyee.add(v.getLeForfait().getNumero());
                }
                response.getWriter().write("<message>"+listRenvoyee+"</message>");
        }
        
        session.setAttribute("moi", dao.litMembre(moi.getNumero()));
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    try {
        processRequest(request, response);
    } catch (GeneralSecurityException ex) {
        Logger.getLogger(trievolforfait.class.getName()).log(Level.SEVERE, null, ex);
    }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    try {
        processRequest(request, response);
    } catch (GeneralSecurityException ex) {
        Logger.getLogger(trievolforfait.class.getName()).log(Level.SEVERE, null, ex);
    }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

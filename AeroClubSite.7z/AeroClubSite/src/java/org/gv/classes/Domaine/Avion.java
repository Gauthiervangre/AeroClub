package org.gv.classes.Domaine;

public class Avion{

private int numero;
private TypeAvion type;
private String immatriculation;
private double tauxHoraire;

public Avion()
{   
}

public Avion(int numero, TypeAvion type, String pImmatriculation, double tauxHoraire){
        this.numero = numero;
        this.type = type;
	this.immatriculation = pImmatriculation;
        this.tauxHoraire = tauxHoraire;
}

public TypeAvion getType(){
	return this.type;
}

public String getImmatriculation(){
	return this.immatriculation;
}

public double getTauxHoraire(){
    return tauxHoraire;
}

public int getNumero(){
    return numero;
}

}

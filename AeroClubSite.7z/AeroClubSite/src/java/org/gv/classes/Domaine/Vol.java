/*
-----------------------------------------------------------TABLE VOL A FAIRE------------------------------------------------------------
 */
package org.gv.classes.Domaine;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author vangr
 */
public class Vol {
    private int numero;
    private int duree; // en heures
    private Avion avion;
    private Membre participant;
    private Instructeur instructeur;
    private Date date;
    
    public Vol(int numero, Membre participant, Instructeur instructeur, Avion avion, Date date, int duree){
        this.numero = numero;
        this.participant = Objects.requireNonNull(participant, "membre null");
        this.avion = avion;
        this.instructeur = instructeur;
        this.date = date;
        this.duree = duree;
    }
    
    public Vol( Membre participant, Instructeur instructeur, Avion avion, Date date, int duree){
        this.participant = Objects.requireNonNull(participant, "membre null");
        this.avion = avion;
        this.instructeur = instructeur;
        this.date = date;
        this.duree = duree;
    }
    
    
    public int getNumero(){
        return numero;
    }   
    
    
    public Date getDate(){
        return date;
    }
    
    public int getDuree() {
        return duree;
    }

    public Avion getAvion() {
        return avion;
    }

    public Membre getParticipant() {
        return participant;
    }
    
    public Instructeur getInstructeur(){
        return instructeur;
    }
    
    
    
    
}

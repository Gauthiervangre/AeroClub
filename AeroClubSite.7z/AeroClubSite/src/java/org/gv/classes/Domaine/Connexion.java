/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gv.classes.Domaine;

/**
 *
 * @author eleve
 */
public class Connexion {
    private String identifiant;
    private String mdp;
    
    public Connexion(String pidentifiant, String mdp){
        this.identifiant = pidentifiant;
        this.mdp = mdp;
    }
    
    public String getIdentifiant(){
        return identifiant;
    }
    
    public String getMdp(){
        return mdp;
    }
    
}

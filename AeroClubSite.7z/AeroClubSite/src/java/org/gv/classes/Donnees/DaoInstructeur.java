package org.gv.classes.Donnees;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.DatabaseMetaData;
import java.lang.Class;
import org.postgresql.Driver;
import org.gv.classes.Domaine.Instructeur;

public class DaoInstructeur{
	PreparedStatement prep;
	Statement stat;
	Connection connection;
	String chemin; //("jdbc:postgresql://192.168.10.33:5432/AeroClub", "gauthier", "admin");
    String user;
    String pass;
	ArrayList<Instructeur> listInstructeur;
    Instructeur instructeur;

	public DaoInstructeur(String pChemin, String puser, String ppass){
            try{
                this.chemin = pChemin;
                this.user = puser;
                this.pass = ppass;
                Class.forName("org.postgresql.Driver");
                this.connection = DriverManager.getConnection(pChemin, puser, ppass);
            }
            catch(ClassNotFoundException eX){
                System.out.println("Class non trouvée");
                eX.printStackTrace();
            }
            catch(SQLException sX){
                System.out.println("SQL error création objet");
                sX.printStackTrace();
            }
            if (this.connection!=null){
                System.out.println("Connexion réussie");
            }
            else{
                System.out.println("Connexion échouée");  
            }
        }

	public Instructeur litInstructeur(int numero){
            try{
                this.prep = this.connection.prepareStatement("SELECT * FROM INSTRUCTEUR WHERE numero= ?");
                this.prep.setLong(1, numero);
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                        instructeur = new Instructeur(res.getInt("numero"), res.getString("nom"), res.getString("prenom"), res.getString("adresse"), res.getString("ville"), res.getString("cp"), res.getString("tel"), res.getString("portable"), res.getString("mail"), res.getString("fax"));
                }
            }
            catch (SQLException eX)
            {
                System.out.println("SQL error lire instructeur");
                eX.printStackTrace();
            }
            return instructeur;
            }
		
	public void ajouterInstructeur(Instructeur instructeur){
            try{
			
                this.prep = this.connection.prepareStatement("INSERT INTO INSTRUCTEUR  (NOM, PRENOM, ADRESSE, CP, VILLE, TEL, PORTABLE, MAIL, FAX) VALUES(?,?,?,?,?,?,?,?,?)");
                this.prep.setString(1, instructeur.getNom());
                this.prep.setString(2, instructeur.getPrenom());
                this.prep.setString(3, instructeur.getAdresse());
                this.prep.setString(4, instructeur.getCp());
                this.prep.setString(5, instructeur.getVille());
                this.prep.setString(6, instructeur.getTel());
                this.prep.setString(7, instructeur.getPortable());
                this.prep.setString(8, instructeur.getMail());
                this.prep.setString(9, instructeur.getFax());
                this.prep.execute();
            }
            catch (SQLException eX)
            {
              System.out.println("SQL error ajouter instructeur");
              eX.printStackTrace();
            }
        }
		

        public void supprimerInstructeur(int numero){
		try{
                    this.prep = this.connection.prepareStatement("DELETE FROM INSTRUCTEUR WHERE numero = ?");
                    this.prep.setLong(1, numero);
                    this.prep.execute();
                }
                catch (SQLException eX)
                {
                    System.out.println("SQL error supprimer instructeur");
                    eX.printStackTrace();
                }
		}
		
        public ArrayList<Instructeur> tousLesInstructeurs(){
            listInstructeur = new ArrayList();
            try{
                this.prep=this.connection.prepareStatement("SELECT * FROM INSTRUCTEUR");
                ResultSet res = this.prep.executeQuery();
                while(res.next()){
                    listInstructeur.add(new Instructeur(res.getInt("numero"), res.getString("NOM"), res.getString("PRENOM"), res.getString("ADRESSE"), res.getString("VILLE"), res.getString("cp"), res.getString("tel"),res.getString("portable"), res.getString("mail"), res.getString("fax")));
                }
                
            }
            catch (SQLException eX)
            {
              System.out.println("SQL error lister tous les instructeurs");
              eX.printStackTrace();
            }
            return listInstructeur;
        }
}
